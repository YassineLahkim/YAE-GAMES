document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.getElementById('sidebar');

    hamburger.addEventListener('click', function(e) {
        e.stopPropagation(); // Empêche la propagation du clic
        this.classList.toggle('active');
        sidebar.classList.toggle('active');
    });

    // Fermer le menu si on clique à l'extérieur
    document.addEventListener('click', function() {
        hamburger.classList.remove('active');
        sidebar.classList.remove('active');
    });

    // Empêcher la fermeture quand on clique dans le menu
    sidebar.addEventListener('click', function(e) {
        e.stopPropagation();
    });

    // Gestion des clics sur les items du menu
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            alert(`Vous avez sélectionné ${this.textContent}`);
            hamburger.classList.remove('active');
            sidebar.classList.remove('active');
        });
    });
});